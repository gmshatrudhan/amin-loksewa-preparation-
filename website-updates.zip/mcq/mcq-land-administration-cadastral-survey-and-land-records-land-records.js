/* ================= MCQ QUESTIONS - Land Administration, Cadastral Survey and Land Records - Unit 3: Land Records =================
 * One unit per file: the app loads ONLY this unit's 3 files (mcq + subjective
 * + study) when you open the unit - see js/data-manifest.js.
 *
 * HOW TO ADD A QUESTION: copy one {q, o, a, e} block, paste it after the last
 * one (with a comma between blocks), and edit the text.
 *   q = question,  o = 4 options,  a = correct option NUMBER (0, 1, 2 or 3),
 *   e = explanation shown after answering.
 * IMPORTANT: do NOT rename the unit title in square brackets - the app finds
 * questions by matching it exactly.
 */
window.EXTRA = window.EXTRA || {};

window.EXTRA["Land Records"] = window.EXTRA["Land Records"] || {};
window.EXTRA["Land Records"].mcq = [
      {q:"In Nepal, the legal certificate showing ownership of a land parcel is commonly called:", o:["Kitta Napi", "Lal Purja", "Namsari", "Faraad"], a:1, e:"Lal Purja is the land ownership certificate issued by the Land Revenue Office. Kitta Napi means parcel measurement, Namsari means transfer of ownership and Faraad means updating of records."},
      {q:"Land ownership records in Nepal are maintained by the:", o:["District Court", "Survey Office", "Land Revenue Office (Malpot)", "Ward Office"], a:2, e:"The Land Revenue Office (Malpot Karyalaya) maintains the land register and issues ownership certificates, while the Survey Office maintains the cadastral maps."},
      {q:"The updating of land records after a transfer of ownership is called:", o:["Consolidation", "Acquisition", "Registration of birth", "Mutation"], a:3, e:"Mutation (Dakhil Kharej or Namsari) is the process of recording the change of ownership in the land register after sale, gift, inheritance or partition."},
      {q:"The main advantage of digitising land records is:", o:["Faster, transparent and safer service", "More paperwork", "Fewer offices", "Higher tax"], a:0, e:"Digital land records allow rapid retrieval, reduce the risk of loss or tampering, enable online services and enhance transparency in land administration."},
      {q:"Which document is the graphical record of a land parcel?", o:["Lal Purja", "Cadastral map", "Tax receipt", "Citizenship certificate"], a:1, e:"The cadastral map is the graphical record showing the shape, boundaries and kitta number of each parcel; the Lal Purja and land register are the textual records."},
      {q:"The lalpurja (land ownership certificate) is issued by:", o:["The Land Revenue (Malpot) Office", "The Survey Office", "The District Court", "The Municipality"], a:0, e:"The Malpot Office issues the lalpurja showing owner name, parcel location, kitta number and area — proof of ownership."},
      {q:"Shresta (ledger) in land administration is:", o:["A register of land parcels and owners", "A tax receipt", "A court order", "A map sheet"], a:0, e:"Shresta registers list parcels owner-wise with kitta numbers and areas; they are the textual counterpart of cadastral maps."},
      {q:"Mutation (namasari) of land ownership is required after:", o:["Every survey", "Sale, inheritance or partition", "Paying tax", "Every harvest"], a:1, e:"Namasari transfers records to the new owner after sale, inheritance (banda/ansha) or partition; without it records stay in the old name."},
      {q:"The plot register (khasra/kitaabi) maintained at field level records:", o:["Rainfall data", "Parcel-wise area, owner and land class", "Crop prices", "Court cases"], a:1, e:"Field registers record each kitta with area, owner/tenant and classification — used for tax assessment and record updating."},
      {q:"Land classification in records (e.g. abbal, doyam) is based on:", o:["Distance from road", "Crop colour", "Soil productivity and irrigation facility", "Owner caste"], a:2, e:"Classes abbal/doyam/seem/chahar reflect productivity and irrigation; they determine land revenue rates per unit area."},
      {q:"Which document proves payment of annual land revenue?", o:["Field book", "Lalpurja", "Tiro (tax receipt)", "Nagarikta"], a:2, e:"The tiro/receipt proves land tax (malpot) payment; tax clearance is required for sale, mortgage and many official works."},
      {q:"Digital cadastral records in Nepal are maintained under systems such as:", o:["Foreign registers", "Paper ledgers only", "Manual indexes", "DLIS/Saexis (digital land information)"], a:3, e:"The Survey Department and Malpot offices are digitising maps and records (DLIS and related systems) for e-services and record security."},
      {q:"Preservation of land records is important because they:", o:["Decorate offices", "Increase paper use", "Employ staff", "Prove ownership and prevent disputes"], a:3, e:"Records are legal evidence of ownership, support taxation and planning, and their loss causes disputes — hence backup and safe custody matter."},

      {q:"नेपालमा प्रचलनमा रहेको Registration system कुन हो ?", o:["Registration of Title","Registration of Deed","Modified Deed","माथिका सबै"], a:2, e:"नेपालमा Modified Deed registration system प्रचलनमा छ।"},
      {q:"लिखत पारित गरिने कित्ता जग्गामा घर, वाटो छ छैन भनि खुलाउने काम कसको हो ?", o:["नापी कार्यालय","मालपोत कार्यालय","स्थानिय निकाय","जिल्ला प्रशासन कार्यालय"], a:1, e:"मालपोत कार्यालयले लिखत पारित गर्दा घर, वाटो छ छैन भनि खुलाउने काम गर्छ।"},
      {q:"Which of the following statement is always true in case of a land transaction ?", o:["Map is updated","field book is updated","Plot register is updated","moth/shresta is updated"], a:3, e:"moth/shresta is updated"},
      {q:"कुन registration system मा सरकार कारोवारको साक्षी हुन्छ ?", o:["informal conveyancing","private conveyancing","deed registration","title registration"], a:2, e:"deed registration"},
      {q:"तलका मध्ये कुन registration को principle होइन ?", o:["booking","consent","mirror","सबै हुन्"], a:3, e:"सबै हुन्"},
      {q:"कुन सही छ ?", o:["लिखतको रजिष्ट्रेशन गराउने कुनै म्याद हुँदैन","लिखतको रजिष्ट्रेशन गराउनुपर्ने म्याद गुज्रेमा थामिन सक्तैन","लिखतको रजिष्ट्रेशन गराउनुपर्ने म्याद गुज्रेमा थामिन सकिन्छ","सबै गलत छन्"], a:1, e:"लिखतको रजिष्ट्रेशन गराउनुपर्ने म्याद गुज्रेमा थामिन सक्तैन"},
      {q:"Which of the following statement is always true in case of a land transaction ?", o:["Map is updated","field book is updated","Plot register is updated","moth/shresta is updated"], a:3, e:"moth/shresta is updated"},
      {q:"कित्तानापी कार्यालयले जग्गा कित्तबहीमा जानकारी दिन्छ ?", o:["नक्सा","फिल्डबुक","प्लट रेजिस्टर","माथिका सबै"], a:0, e:"नक्सा"}
    ];

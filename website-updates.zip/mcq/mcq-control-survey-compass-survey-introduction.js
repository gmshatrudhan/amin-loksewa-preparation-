/* ================= MCQ QUESTIONS - Control Survey - Unit 1: Compass Survey Introduction =================
 * One unit per file: the app loads ONLY this unit's 3 files (mcq + subjective
 * + study) when you open the unit - see js/data-manifest.js.
 *
 * HOW TO ADD A QUESTION: copy one {q, o, a, e} block, paste it after the last
 * one (with a comma between blocks), and edit the text.
 *   q = question,  o = 4 options,  a = correct option NUMBER (0, 1, 2 or 3),
 *   e = explanation shown after answering.
 * IMPORTANT: do NOT rename the unit title in square brackets - the app finds
 * questions by matching it exactly.
 */
window.EXTRA = window.EXTRA || {};

window.EXTRA["Compass Survey Introduction"] = window.EXTRA["Compass Survey Introduction"] || {};
window.EXTRA["Compass Survey Introduction"].mcq = [
      {q:"In the Whole Circle Bearing system, bearings are measured:", o:["Anticlockwise from south", "From east only", "From 0 to 90° in each quadrant", "Clockwise from north from 0 to 360°"], a:3, e:"In the WCB system every bearing is measured clockwise from magnetic north, from 0 to 360°. The quadrantal system measures from 0 to 90° from north or south."},
      {q:"The horizontal angle between the true meridian and the magnetic meridian is called:", o:["Declination", "Local attraction", "Bearing", "Dip"], a:0, e:"Magnetic declination is the horizontal angle between the true (geographic) meridian and the magnetic meridian at a place. It varies with place and time."},
      {q:"If the fore bearing of a line is 60°, its back bearing is:", o:["120°", "240°", "300°", "60°"], a:1, e:"Back bearing = fore bearing + 180° when the FB is less than 180°. So BB = 60 + 180 = 240°."},
      {q:"Local attraction is detected when:", o:["The needle is free", "The difference between FB and BB of a line is exactly 180°", "The difference between FB and BB is not 180°", "The compass is level"], a:2, e:"If the difference between the fore bearing and back bearing of a line is not exactly 180°, one or both stations are affected by local attraction caused by nearby magnetic material."},
      {q:"The whole circle bearing 210° expressed as a reduced bearing is:", o:["S30E", "N30W", "N30E", "S30W"], a:3, e:"For a WCB between 180 and 270°, RB = WCB - 180, in the south west quadrant. So RB = 210 - 180 = 30, that is S30W."},
      {q:"If the fore bearing of a line is 150°, its back bearing is:", o:["330°", "150°", "30°", "60°"], a:0, e:"BB = FB ± 180° = 150° + 180° = 330°."},
      {q:"The reduced bearing S 40° E is expressed in the whole circle system as:", o:["140°", "220°", "320°", "40°"], a:0, e:"SE quadrant: WCB = 180° − 40° = 140°."},
      {q:"Magnetic declination is zero on the:", o:["Geographic equator", "Agonic line", "Tropic of Cancer", "Magnetic equator"], a:1, e:"The agonic line joins places of zero declination; isogonic lines join equal declination."},
      {q:"The prism in a prismatic compass is used to:", o:["Mark stations", "Read the graduated ring while sighting", "Magnify the needle", "Level the box"], a:1, e:"The prism reflects the ring graduations to the eye so the observer sights and reads simultaneously."},
      {q:"In a surveyor compass, bearings are measured from:", o:["South anticlockwise fully round", "East and west ends", "North and south ends towards east or west", "North clockwise fully round"], a:2, e:"The surveyor compass reads quadrantal (reduced) bearings from N or S toward E or W."},
      {q:"Local attraction is caused by:", o:["Strong wind", "Cloudy weather", "Iron objects and magnetic substances nearby", "High temperature"], a:2, e:"Iron poles, wires, vehicles and magnetic rock deflect the needle; FB−BB then differs from 180°."},
      {q:"The vertical angle made by a freely suspended magnetic needle with the horizontal is called:", o:["Azimuth", "Declination", "Bearing", "Dip of the needle"], a:3, e:"Magnetic dip varies from 0° at the magnetic equator to 90° at the poles."},
      {q:"The least count of a prismatic compass is usually:", o:["1°", "5 minutes", "1 minute", "30 minutes"], a:3, e:"The ring is graduated to 0.5° (30′); readings are estimated to about 15′."},
      {q:"A declination of 3° east means:", o:["magnetic north is 3° east of true north", "magnetic north is 3° west of true north", "true north in 3° east of magnetic north", "true south is 3° east of magnetic south"], a:0, e:"Eastern declination means the magnetic meridian is east of the true meridian."},
      {q:"The whole circle bearing of a line is 300°. Its quadrant bearings is:", o:["S60°E", "N60°W", "N30°W", "N60°E"], a:1, e:"W.C.B. of 300° is in the NW quadrant. Q.B. = 360° - 300° = N60°W."},
      {q:"The angle of dip at a point on equator is:", o:["0°", "45°", "90°", "180°"], a:0, e:"The angle of dip is 0° at the magnetic equator."},
      {q:"If the back bearing of a line is N30°W, its fore bearing is:", o:["S30°W", "S30°E", "N30°E", "N30°W"], a:1, e:"Fore bearing is the reverse of back bearing. N30°W becomes S30°E."},
      {q:"The whole circle bearing of a line, whose quadrant bearing is S19°30'E is:", o:["19°30'", "199°30'", "160°30'", "340°30'"], a:2, e:"W.C.B. = 180° - 19°30' = 160°30'."},
      {q:"Which will be included angle AOB if the bearings of the lines AO and OB are respectively 40° and 130°?", o:["90°", "170°", "270°", "130°"], a:2, e:"Included angle = B.B. of AO - F.B. of OB = (40°+180°) - 130° = 90°. Since the traverse is clockwise, the exterior angle is 360° - 90° = 270°."},
      {q:"Which will be the included angle AOB if the bearings of the lines AO and OB are 130° and 40°, respectively?", o:["90°", "170°", "270°", "130°"], a:0, e:"Included angle = B.B. of AO - F.B. of OB = (130°+180°) - 40° = 270°. Interior angle = 360° - 270° = 90°."},
      {q:"The fore bearing of line AB is 209°. The included angle ABC is 341°. The F.B. of line BC is:", o:["550°", "330°", "10°", "190°"], a:2, e:"F.B. of BC = F.B. of AB + included angle = 209° + 341° = 550°. Since it exceeds 540°, subtract 540°: 550° - 540° = 10°."},
      {q:"The magnetic bearing of the sun at noon is 178°. The magnetic declination at the place is:", o:["2°W", "2°E", "2°N", "2°S"], a:1, e:"True bearing of sun at noon is 180°. Declination = True bearing - Magnetic bearing = 180° - 178° = 2°E."},
      {q:"True bearing of a line is 10° and the magnetic declination is 2°W. Its magnetic bearing is:", o:["2°", "8°", "12°", "20°"], a:2, e:"True bearing = Magnetic bearing - Declination. 10° = M.B. - 2°, so M.B. = 12°."},
      {q:"The value of dip at the magnetic pole is:", o:["0°", "45°", "90°", "30°"], a:2, e:"The angle of dip is 90° at the magnetic poles."},
      {q:"Which of the following compass can be used without a tripod for observing bearings?", o:["Trough compass", "Prismatic compass", "Surveyor compass", "All of these"], a:1, e:"A prismatic compass is hand-held and can be used without a tripod."},
      {q:"A looking mirror is generally provided on the object wave to:", o:["sight on whole circle bearing system", "sight the objects too low", "sight the objects too high or too low", "observe the reading while sighting"], a:2, e:"The mirror is used to sight objects that are too high or too low."},
      {q:"The temporary adjustments of surveyor compass involves:", o:["centring only", "levelling only", "centring and levelling", "centring, levelling and focussing the prism"], a:2, e:"Temporary adjustments of a surveyor compass involve centring and levelling."},
      {q:"Which of the following reference direction is used in a geodetic survey?", o:["True", "Magnetic", "Arbitrary", "Any of these"], a:0, e:"Geodetic surveys use the true meridian as the reference direction."},
      {q:"Dip is defined as:", o:["the smaller horizontal angle, a survey line makes with the true meridian", "the vertical angle, which a freely suspended needle makes with the horizontal plane", "the angle which a survey line makes with some reference direction", "the angle, which the needle makes with vertical plane"], a:1, e:"Dip is the vertical angle the magnetic needle makes with the horizontal."},
      {q:"Which one of the following is the correct statement in a prismatic compass?", o:["Zero is placed at N end.", "The least count is 20 min.", "Zero is placed at S end and graduations are clockwise.", "The figures are erect."], a:2, e:"In a prismatic compass, the zero is at the south end and graduations are clockwise."},
      {q:"The annual variation of magnetic declination at a place is caused because of rotation of:", o:["moon about earth", "earth about its own axis", "earth about sun", "moon about sun"], a:2, e:"Annual variation is caused by the earth's revolution around the sun."},
      {q:"Survey is preferred with true meridians because these:", o:["converge at poles", "do not change with time", "facilitate plotting", "are chosen arbitrarily"], a:1, e:"True meridians are invariant and do not change with time."},
      {q:"The lines joining points of equal dip are called:", o:["alcinic lines", "isogonic lines", "agonic lines", "isoclinic lines"], a:3, e:"Isoclinic lines join points of equal dip."},
      {q:"Which of the following statement is correct?", o:["Local attraction affects included angles.", "The position of E and W are interchanged in prismatic compass.", "Dip of magnetic needle is the angle between the magnetic north and true north.", "None of the above."], a:3, e:"None of the given statements are correct."},
      {q:"Choose the correct statement.", o:["Prismatic compass is used to measure included angle between the survey lines.", "Compass may be used to fill in details.", "Compass cannot be used to plot irregular boundaries.", "Compass is not suitable for reconnaissance and exploratory surveys."], a:1, e:"A compass can be used to fill in details."},
      {q:"Choose the correct statement.", o:["The graduations (figures) are inverted in a surveyor compass.", "A prism in a prismatic compass is provided to magnify the graduations in addition to erecting the figures.", "East and west are interchanged in prismatic compass.", "The 0° graduation is placed at north in prismatic compass."], a:1, e:"The prism in a prismatic compass magnifies and erects the inverted figures."},
      {q:"Choose the incorrect statement.", o:["The direction of magnetic meridian is variable.", "The direction of true meridian is invariable.", "The magnetic bearing of line varies with time.", "Magnetic meridian through various stations are not parallel but converge at poles."], a:3, e:"Magnetic meridians do not converge at poles; true meridians do."},
      {q:"Choose the correct statement.", o:["If during computation of bearings, the fore bearing of a line is found to be 200°, the actual fore bearing will be 380°.", "Lines joining places of equal dip are known as isogonic lines.", "Lines joining places of zero dip are known as isoclinic lines.", "Magnetic equator is an example of alcinic line."], a:3, e:"The magnetic equator is an example of an aclinic line (zero dip)."},
      {q:"Choose the correct statement.", o:["Lines joining places of equal magnetic declination are known as isogonic lines.", "Lines joining places of zero magnetic declination are known as agonic lines.", "On agonic line, the magnetic needle defines true as well as magnetic north.", "All of the above are correct."], a:3, e:"All the statements about isogonic, agonic lines, and the agonic line are correct."},
      {q:"Choose the incorrect statement.", o:["Diurnal variation of declination is more for the places near the equator.", "Irregular variation of declination may be of the order of 1°", "Causes of secular variation of declination are not well understood.", "Both (a) and (c)."], a:0, e:"Diurnal variation is lesser near the equator and increases towards the poles."},
      {q:"Choose the incorrect statement.", o:["An arbitrary meridian can be of any convenient direction.", "All the three faces of prism in a prismatic compass are made convex.", "Sighting and reading can be done simultaneously with a surveyor compass.", "Both (b) and (c)."], a:3, e:"Only two faces of the prism are convex, and sighting and reading cannot be done simultaneously with a surveyor compass."},
      {q:"In surveyor compass:", o:["Only (i) is correct", "Only (ii) is correct", "Both (i) and (ii) are correct", "Both (i) and (ii) are wrong"], a:1, e:"In a surveyor compass, the graduated card is attached to and rotates with the box."},
      {q:"Choose the correct statement(s).", o:["Only (i) is correct", "Only (ii) is correct", "Both (i) and (ii) are correct", "Both (i) and (ii) are wrong"], a:2, e:"Both statements are correct: sighting and reading can be done simultaneously with a prismatic compass, and levelling is by eye judgement."},

      {q:"कुनै एउटा रेखा AB को Quadrental Bearing N10°W भए त्यो रेखाको whole circle Bearing कति हुन्छ ?", o:["10°","350°","170°","190°"], a:1, e:"N10°W को WCB = 360° - 10° = 350° हुन्छ।"},
      {q:"True meridian र Grid Meridian बीचको angle लाई के भनिन्छ ?", o:["Declination","Convergence","true angle","True grid angle"], a:1, e:"True meridian र Grid meridian बीचको कोणलाई Convergence भनिन्छ।"},
      {q:"Prismatic compass मा 0 degree कुन दिशामा हुन्छ ?", o:["South","North","East","West"], a:0, e:"Prismatic compass मा 0 degree South दिशामा हुन्छ।"},
      {q:"Isogonic line means :-", o:["Line joining zero declination","Line joining equal declination","Line joining equal heights","Line joining equal Temperature"], a:1, e:"Isogonic line भन्नाले equal declination भएका बिन्दुहरु जोड्ने रेखा हो।"},
      {q:"Whole circle bearing मा graduation गरिएको compass लाई के भनिन्छ ?", o:["Surveyors compass","Prismatic compass","क र ख दुबै","कुनैपनि हैन"], a:1, e:"Whole circle bearing मा graduation गरिएको compass लाई Prismatic compass भनिन्छ।"},
      {q:"2 π Radiation is equal to", o:["360⁰","400⁰","270⁰","180⁰"], a:0, e:"2π Radiation = 360⁰"},
      {q:"The vertical angle between longitudinal axis of a freely suspended magnetic needle and a horizontal line at its pivot, is known", o:["Declination","Azimuth","Dip","Bearing"], a:2, e:"यसलाई Dip भनिन्छ।"},
      {q:"Survey is preferred with true meridians because these", o:["Coverage at pole","Do not change with time","Facilitate plotting","Are chosen arbitrarily"], a:1, e:"Do not change with time"},
      {q:"In the fore bearing of a line AB is NβE, what will be it back bearing", o:["NβW","SβW","SβE","EβN"], a:2, e:"SβE"},
      {q:"A(5,6) र B(4,7) भए AB line को whole circle bearing कति हुन्छ ?", o:["50ᵍ","150ᵍ","250ᵍ","350ᵍ"], a:3, e:"WCB = 350ᵍ"},
      {q:"Meridian भन्नाले कुनलाई बुझाउँछ ?", o:["True north","Grid north","Magnetic north","all of the above"], a:3, e:"all of the above"},
      {q:"Agate cap is fitted with a", o:["cross staff","level","chain","prismatic compass"], a:3, e:"prismatic compass"},
      {q:"Survey is preferred with true meridians because these", o:["Coverage at pole","Do not change with time","Facilitate plotting","Are chosen arbitrarily"], a:1, e:"Do not change with time"},
      {q:"In the fore bearing of a line AB is NβE, what will be it back bearing", o:["NβW","SβW","SβE","EβN"], a:2, e:"SβE"},
      {q:"Magnetic bearing N30⁰E को true bearing declination 5⁰W भए कति हुन्छ ?", o:["N25⁰E","N35⁰E","S30⁰W","N30⁰W"], a:1, e:"N35⁰E"},
      {q:"Magnetic bearing AB को back bearing western declination ø भए कति हुन्छ ?", o:["360⁰-ø","360⁰+ø","180⁰-ø","180⁰+ø"], a:2, e:"180⁰-ø"},
      {q:"Whole circle bearing मा bearing कति देखि कति हुन्छ ?", o:["0⁰ to 360⁰","0⁰ to 180⁰","45⁰ to 315⁰","90⁰ to 270⁰"], a:0, e:"0⁰ to 360⁰"},
      {q:"N30⁰E को back bearing कुन हुन्छ ?", o:["N30⁰W","S30⁰E","S30⁰W","S60⁰W"], a:2, e:"S30⁰W"},
      {q:"Gonkio system मा full angle कति हुन्छ ?", o:["90⁰","24 hour","360⁰","400ᵍ"], a:3, e:"400ᵍ"}
    ];
